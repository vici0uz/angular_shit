export interface ModalData {
    content: string;
    title: string;
}