import { Component, EventEmitter, OnDestroy, Output } from '@angular/core';
import { ModalService } from '../modal.service';
import { ModalData } from './modalData';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrl: './modal.component.css'
})

export class ModalComponent implements OnDestroy{
  display = false;
  data: any;
  
  private showModalSubscription;

  constructor(private modalService: ModalService){
    this.showModalSubscription = this.modalService.showModal$.subscribe((show)=> {
      this.display=show;
      this.data = this.modalService.data
    })
  }

 ngOnDestroy() {
    this.showModalSubscription.unsubscribe();
  }

}
